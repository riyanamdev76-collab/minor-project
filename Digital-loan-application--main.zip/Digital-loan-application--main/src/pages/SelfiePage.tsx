import { useState } from 'react';
import { Camera, CheckCircle, Upload } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function SelfiePage() {
  const navigate = useNavigate();
  const [uploaded, setUploaded] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploaded(true);
      localStorage.setItem('selfieUploaded', 'true');
    }
  };

  const handleContinue = () => {
    setLoading(true);
    setTimeout(() => {
      navigate('/aadhar-kyc');
    }, 1000);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Camera className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Selfie Verification</h1>
          </div>
          <p className="text-blue-100">
            Please upload a clear selfie for identity verification
          </p>
        </div>

        <div className="p-6">
          <div className="bg-blue-50 rounded-2xl p-6 border border-blue-200 mb-6">
            <h3 className="font-semibold text-gray-900 mb-3">Guidelines for a good selfie:</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                Make sure your face is clearly visible
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                Use good lighting, avoid shadows
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                Remove sunglasses or hats
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                Look directly at the camera
              </li>
            </ul>
          </div>

          <div className="border-2 border-dashed border-gray-300 rounded-2xl p-12 text-center mb-6">
            {uploaded ? (
              <div className="space-y-4">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="w-10 h-10 text-green-600" />
                </div>
                <p className="font-semibold text-gray-900">Selfie Uploaded Successfully!</p>
                <p className="text-sm text-gray-600">Your photo has been captured</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <Upload className="w-10 h-10 text-blue-600" />
                </div>
                <div>
                  <label
                    htmlFor="selfie-upload"
                    className="cursor-pointer inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                  >
                    Upload Selfie
                  </label>
                  <input
                    id="selfie-upload"
                    type="file"
                    accept="image/*"
                    capture="user"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
                <p className="text-sm text-gray-600">
                  Click to upload or take a photo using your camera
                </p>
              </div>
            )}
          </div>

          <button
            onClick={handleContinue}
            disabled={!uploaded || loading}
            className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Processing...' : 'Continue to KYC'}
          </button>
        </div>
      </div>
    </div>
  );
}
