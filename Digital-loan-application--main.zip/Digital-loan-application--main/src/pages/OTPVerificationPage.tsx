import { useState } from 'react';
import { Shield, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function OTPVerificationPage() {
  const navigate = useNavigate();
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleVerify = () => {
    const otpValue = otp.join('');
    if (otpValue.length !== 6) {
      alert('Please enter complete OTP');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      localStorage.setItem('loanDisbursed', 'true');
      navigate('/loan-disbursed');
    }, 2000);
  };

  const handleResend = () => {
    alert('OTP has been resent to your registered mobile number');
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-8 h-8" />
            <h1 className="text-2xl font-bold">OTP Verification</h1>
          </div>
          <p className="text-blue-100">Enter the OTP sent to your registered mobile number</p>
        </div>

        <div className="p-6">
          <div className="text-center mb-8">
            <p className="text-gray-600 mb-2">We've sent a 6-digit OTP to</p>
            <p className="text-lg font-semibold text-gray-900">+91 XXXXX XX234</p>
          </div>

          <div className="flex justify-center gap-3 mb-8">
            {otp.map((digit, index) => (
              <input
                key={index}
                id={`otp-${index}`}
                type="text"
                value={digit}
                onChange={(e) => handleOtpChange(index, e.target.value.replace(/\D/g, ''))}
                onKeyDown={(e) => handleKeyDown(index, e)}
                maxLength={1}
                className="w-12 h-12 text-center text-2xl font-bold border-2 border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            ))}
          </div>

          <button
            onClick={handleVerify}
            disabled={loading || otp.join('').length !== 6}
            className="w-full bg-blue-600 text-white py-4 rounded-lg font-bold text-lg hover:bg-blue-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mb-4"
          >
            {loading ? (
              'Verifying & Disbursing Loan...'
            ) : (
              <>
                <CheckCircle className="w-5 h-5" />
                Verify & Disburse Loan
              </>
            )}
          </button>

          <div className="text-center">
            <button
              onClick={handleResend}
              className="text-blue-600 hover:text-blue-700 font-medium text-sm"
            >
              Didn't receive OTP? Resend
            </button>
          </div>

          <div className="bg-amber-50 rounded-lg p-4 border border-amber-200 mt-6">
            <p className="text-sm text-gray-700">
              <strong>Note:</strong> This is the final step. Upon successful verification, your loan will be disbursed to your registered bank account immediately.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
