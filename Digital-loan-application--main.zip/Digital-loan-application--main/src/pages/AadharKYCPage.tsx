import { useState } from 'react';
import { Shield, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AadharKYCPage() {
  const navigate = useNavigate();
  const [aadharNumber, setAadharNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [verified, setVerified] = useState(false);

  const handleSendOTP = () => {
    if (aadharNumber.length !== 12) {
      alert('Please enter a valid 12-digit Aadhar number');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setOtpSent(true);
      setLoading(false);
      alert('OTP sent to your registered mobile number');
    }, 1000);
  };

  const handleVerifyOTP = () => {
    setLoading(true);
    setTimeout(() => {
      setVerified(true);
      setLoading(false);
      localStorage.setItem('aadharVerified', 'true');
    }, 1500);
  };

  const handleContinue = () => {
    navigate('/credit-check');
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Aadhar KYC Verification</h1>
          </div>
          <p className="text-indigo-100">
            Verify your identity using Aadhar OTP
          </p>
        </div>

        <div className="p-6">
          {!verified ? (
            <>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Aadhar Number
                </label>
                <input
                  type="text"
                  value={aadharNumber}
                  onChange={(e) => setAadharNumber(e.target.value.replace(/\D/g, '').slice(0, 12))}
                  placeholder="Enter 12-digit Aadhar number"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  disabled={otpSent}
                />
              </div>

              {!otpSent ? (
                <button
                  onClick={handleSendOTP}
                  disabled={loading || aadharNumber.length !== 12}
                  className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Sending OTP...' : 'Send OTP'}
                </button>
              ) : (
                <>
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Enter OTP
                    </label>
                    <input
                      type="text"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      placeholder="Enter 6-digit OTP"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-center text-2xl tracking-widest"
                      maxLength={6}
                    />
                    <p className="text-sm text-gray-500 mt-2 text-center">
                      OTP sent to mobile number linked with Aadhar
                    </p>
                  </div>

                  <button
                    onClick={handleVerifyOTP}
                    disabled={loading || otp.length !== 6}
                    className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {loading ? 'Verifying...' : 'Verify OTP'}
                  </button>
                </>
              )}
            </>
          ) : (
            <div className="text-center py-8">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-12 h-12 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                KYC Verified Successfully!
              </h2>
              <p className="text-gray-600 mb-6">
                Your Aadhar verification is complete
              </p>
              <button
                onClick={handleContinue}
                className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
              >
                Continue to Credit Check
              </button>
            </div>
          )}

          <div className="bg-amber-50 rounded-lg p-4 border border-amber-200 mt-6">
            <p className="text-sm text-gray-700">
              <strong>Note:</strong> Your Aadhar information is securely encrypted and used only for verification purposes. We comply with all data protection regulations.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
