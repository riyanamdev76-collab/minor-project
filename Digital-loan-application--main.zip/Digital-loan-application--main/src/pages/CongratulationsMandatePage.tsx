import { CheckCircle, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function CongratulationsMandatePage() {
  const navigate = useNavigate();
  const approvedAmount = 500000;

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('en-IN');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 px-6 md:px-10 py-12 text-center text-white">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-white/20 rounded-full animate-pulse" />
                <CheckCircle className="w-20 h-20 relative" />
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Credit Approved!</h1>
            <p className="text-green-100 text-lg">Your credit limit has been verified</p>
          </div>

          <div className="p-6 md:p-10">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-8 mb-8 border border-green-200">
              <div className="text-center">
                <p className="text-gray-600 text-sm md:text-base mb-2">Approved Credit Limit</p>
                <div className="text-5xl md:text-6xl font-bold text-green-600 mb-2">
                  ₹{formatCurrency(approvedAmount)}
                </div>
                <p className="text-gray-500 text-sm">Next step: Set up auto-debit mandate</p>
              </div>
            </div>

            <div className="bg-blue-50 rounded-2xl p-6 mb-8 border border-blue-200">
              <h3 className="font-semibold text-gray-900 mb-4">What's Next?</h3>
              <p className="text-gray-700 text-sm mb-4">
                To complete your loan setup, you need to authorize automatic EMI deductions from your bank account. This ensures timely payments and helps maintain your credit score.
              </p>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-semibold mt-0.5">
                    1
                  </div>
                  Set up e-mandate for EMI auto-debit
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-semibold mt-0.5">
                    2
                  </div>
                  Review and sign loan agreement
                </li>
                <li className="flex items-start gap-2">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-xs font-semibold mt-0.5">
                    3
                  </div>
                  Receive loan amount in your account
                </li>
              </ul>
            </div>

            <button
              onClick={() => navigate('/mandate')}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-lg font-bold text-lg hover:from-green-700 hover:to-emerald-700 transition-all shadow-lg flex items-center justify-center gap-2 group"
            >
              Set Up Auto-Debit Mandate
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
