import { useNavigate } from 'react-router-dom';
import { ArrowRight, Shield, Clock, CreditCard, CheckCircle } from 'lucide-react';

export default function HomePage() {
  const navigate = useNavigate();

  const features = [
    {
      icon: Clock,
      title: 'Quick Approval',
      description: 'Get approved in minutes, not days',
    },
    {
      icon: Shield,
      title: 'Secure & Safe',
      description: 'Bank-level security for your data',
    },
    {
      icon: CreditCard,
      title: 'Flexible EMI',
      description: 'Choose plans that fit your budget',
    },
  ];

  const benefits = [
    'Instant loan approval up to ₹5 Lakhs',
    'Competitive interest rates starting at 1.5% per month',
    'Flexible repayment tenure from 3 to 36 months',
    'Minimal documentation required',
    'No hidden charges or fees',
    '24/7 customer support',
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4">
            Get Your Loan in
            <span className="text-blue-600"> Minutes</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Fast, secure, and hassle-free personal loans with competitive rates and flexible terms
          </p>
          <button
            onClick={() => navigate('/application')}
            className="bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-700 transition-all shadow-lg inline-flex items-center gap-2 group"
          >
            Apply Now
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <Icon className="w-7 h-7 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden mb-16">
          <div className="grid md:grid-cols-2">
            <div className="p-10">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Why Choose Us?
              </h2>
              <ul className="space-y-4">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-10 flex flex-col justify-center text-white">
              <h3 className="text-2xl font-bold mb-4">Ready to get started?</h3>
              <p className="text-blue-100 mb-6">
                Join thousands of satisfied customers who have received their loans quickly and easily.
              </p>
              <button
                onClick={() => navigate('/application')}
                className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-all inline-flex items-center justify-center gap-2 group"
              >
                Start Your Application
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>

        <div className="bg-amber-50 rounded-2xl p-8 border border-amber-200">
          <h3 className="text-xl font-bold text-gray-900 mb-4 text-center">
            How It Works
          </h3>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '1', title: 'Apply Online', desc: 'Fill out our simple application form' },
              { step: '2', title: 'Get Approved', desc: 'Receive instant approval decision' },
              { step: '3', title: 'Choose EMI', desc: 'Select your preferred payment plan' },
              { step: '4', title: 'Receive Funds', desc: 'Money transferred to your account' },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-3">
                  {item.step}
                </div>
                <h4 className="font-bold text-gray-900 mb-2">{item.title}</h4>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
