import { CheckCircle, ArrowRight } from 'lucide-react';

interface CongratulationsPageProps {
  onContinue: () => void;
}

export default function CongratulationsPage({ onContinue }: CongratulationsPageProps) {
  const approvedAmount = 500000;

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('en-IN');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-green-600 to-emerald-600 px-6 md:px-10 py-12 text-center text-white">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="absolute inset-0 bg-white/20 rounded-full animate-pulse" />
                <CheckCircle className="w-20 h-20 relative" />
              </div>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Congratulations!</h1>
            <p className="text-green-100 text-lg">Your loan application has been approved</p>
          </div>

          <div className="p-6 md:p-10">
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-8 mb-8 border border-green-200">
              <div className="text-center">
                <p className="text-gray-600 text-sm md:text-base mb-2">Approved Loan Amount</p>
                <div className="text-5xl md:text-6xl font-bold text-green-600 mb-2">
                  ₹{formatCurrency(approvedAmount)}
                </div>
                <p className="text-gray-500 text-sm">You can now proceed to select your EMI plan</p>
              </div>
            </div>

            <div className="bg-blue-50 rounded-2xl p-6 mb-8 border border-blue-200">
              <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                  i
                </div>
                What happens next?
              </h3>
              <ul className="space-y-3">
                <li className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-sm font-semibold mt-0.5">
                    1
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Choose Your EMI Plan</p>
                    <p className="text-sm text-gray-600">Select a tenure that works best for your budget</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-sm font-semibold mt-0.5">
                    2
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Review Terms & Conditions</p>
                    <p className="text-sm text-gray-600">Understand your repayment schedule</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-sm font-semibold mt-0.5">
                    3
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">Receive Funds</p>
                    <p className="text-sm text-gray-600">Amount will be disbursed to your account</p>
                  </div>
                </li>
              </ul>
            </div>

            <div className="bg-amber-50 rounded-2xl p-6 mb-8 border border-amber-200">
              <h4 className="font-semibold text-gray-900 mb-3">Key Details</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-lg p-4">
                  <p className="text-gray-600 text-sm mb-1">Processing Fee</p>
                  <p className="text-lg font-semibold text-gray-900">2.5%</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <p className="text-gray-600 text-sm mb-1">Interest Rate</p>
                  <p className="text-lg font-semibold text-gray-900">1.5% p.m.</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <p className="text-gray-600 text-sm mb-1">Min Tenure</p>
                  <p className="text-lg font-semibold text-gray-900">3 months</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <p className="text-gray-600 text-sm mb-1">Max Tenure</p>
                  <p className="text-lg font-semibold text-gray-900">60 months</p>
                </div>
              </div>
            </div>

            <button
              onClick={onContinue}
              className="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-lg font-bold text-lg hover:from-green-700 hover:to-emerald-700 transition-all shadow-lg flex items-center justify-center gap-2 group"
            >
              Choose Your EMI Plan
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        <p className="text-center text-gray-600 text-sm mt-6">
          Have questions? Contact our support team at support@loanapp.com
        </p>
      </div>
    </div>
  );
}
