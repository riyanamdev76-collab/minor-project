import { useState } from 'react';
import { CreditCard, Building2, CheckCircle, XCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

type MandateMethod = 'netbanking' | 'debit-card' | null;

export default function MandatePage() {
  const navigate = useNavigate();
  const [selectedMethod, setSelectedMethod] = useState<MandateMethod>(null);
  const [showResult, setShowResult] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleMethodSelect = (method: MandateMethod) => {
    setSelectedMethod(method);
    setShowResult(false);
  };

  const handleSuccess = () => {
    setIsSuccess(true);
    setShowResult(true);
    localStorage.setItem('mandateStatus', 'success');
  };

  const handleFailure = () => {
    setIsSuccess(false);
    setShowResult(true);
    localStorage.setItem('mandateStatus', 'failure');
  };

  const handleContinue = () => {
    if (isSuccess) {
      navigate('/withdrawal-summary');
    }
  };

  const handleRetry = () => {
    setShowResult(false);
    setSelectedMethod(null);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-8 text-white">
          <h1 className="text-2xl font-bold mb-2">Set Up E-Mandate</h1>
          <p className="text-purple-100">
            Authorize automatic EMI deductions from your bank account
          </p>
        </div>

        <div className="p-6">
          {!showResult ? (
            <>
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Choose Payment Method
                </h2>
                <div className="grid md:grid-cols-2 gap-4">
                  <button
                    onClick={() => handleMethodSelect('netbanking')}
                    className={`p-6 rounded-xl border-2 transition-all ${
                      selectedMethod === 'netbanking'
                        ? 'border-purple-600 bg-purple-50'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <Building2
                      className={`w-12 h-12 mx-auto mb-3 ${
                        selectedMethod === 'netbanking' ? 'text-purple-600' : 'text-gray-400'
                      }`}
                    />
                    <h3 className="font-semibold text-gray-900 mb-1">Net Banking</h3>
                    <p className="text-sm text-gray-600">
                      Authenticate using your bank's internet banking
                    </p>
                  </button>

                  <button
                    onClick={() => handleMethodSelect('debit-card')}
                    className={`p-6 rounded-xl border-2 transition-all ${
                      selectedMethod === 'debit-card'
                        ? 'border-purple-600 bg-purple-50'
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                  >
                    <CreditCard
                      className={`w-12 h-12 mx-auto mb-3 ${
                        selectedMethod === 'debit-card' ? 'text-purple-600' : 'text-gray-400'
                      }`}
                    />
                    <h3 className="font-semibold text-gray-900 mb-1">Debit Card</h3>
                    <p className="text-sm text-gray-600">
                      Set up mandate using your debit card
                    </p>
                  </button>
                </div>
              </div>

              {selectedMethod && (
                <div className="bg-amber-50 rounded-lg p-4 border border-amber-200 mb-6">
                  <p className="text-sm text-gray-700 mb-4">
                    <strong>For demo purposes:</strong> Choose whether the mandate should succeed or fail
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={handleSuccess}
                      className="flex-1 bg-green-600 text-white py-2 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <CheckCircle className="w-5 h-5" />
                      Simulate Success
                    </button>
                    <button
                      onClick={handleFailure}
                      className="flex-1 bg-red-600 text-white py-2 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <XCircle className="w-5 h-5" />
                      Simulate Failure
                    </button>
                  </div>
                </div>
              )}

              <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                <h4 className="font-semibold text-gray-900 mb-2">What is E-Mandate?</h4>
                <p className="text-sm text-gray-700">
                  E-Mandate is a secure authorization that allows us to automatically deduct your EMI amount from your bank account on the due date. This ensures you never miss a payment and helps maintain your credit score.
                </p>
              </div>
            </>
          ) : (
            <div className="text-center py-8">
              {isSuccess ? (
                <>
                  <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-12 h-12 text-green-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">
                    Mandate Setup Successful!
                  </h2>
                  <p className="text-gray-600 mb-6">
                    Your auto-debit mandate has been activated successfully
                  </p>
                  <button
                    onClick={handleContinue}
                    className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                  >
                    Continue to Summary
                  </button>
                </>
              ) : (
                <>
                  <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <XCircle className="w-12 h-12 text-red-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">Mandate Setup Failed</h2>
                  <p className="text-gray-600 mb-6">
                    We couldn't set up your auto-debit mandate. Please try again.
                  </p>
                  <button
                    onClick={handleRetry}
                    className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                  >
                    Try Again
                  </button>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
