import { useState } from 'react';
import { Check, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface EMIPlan {
  tenure: number;
  emiAmount: number;
  totalAmount: number;
  totalInterest: number;
  recommended?: boolean;
}

interface DummySchemePageProps {
  approvedAmount?: number;
}

const DummySchemePage = ({ approvedAmount = 500000 }: DummySchemePageProps) => {
  const navigate = useNavigate();
  const [selectedTenure, setSelectedTenure] = useState(12);
  const [checkBox, setCheckBox] = useState(true);
  const [loading, setLoading] = useState(false);

  const monthlyROI = 0.015;
  const processingFeePercent = 0.025;
  const processingFee = approvedAmount * processingFeePercent;

  const calculateEMI = (principal: number, monthlyRate: number, months: number) => {
    const emi =
      (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) /
      (Math.pow(1 + monthlyRate, months) - 1);
    return Math.round(emi);
  };

  const emiPlans: EMIPlan[] = [
    {
      tenure: 3,
      emiAmount: calculateEMI(approvedAmount, monthlyROI, 3),
      totalAmount: calculateEMI(approvedAmount, monthlyROI, 3) * 3,
      totalInterest: calculateEMI(approvedAmount, monthlyROI, 3) * 3 - approvedAmount,
      recommended: false,
    },
    {
      tenure: 6,
      emiAmount: calculateEMI(approvedAmount, monthlyROI, 6),
      totalAmount: calculateEMI(approvedAmount, monthlyROI, 6) * 6,
      totalInterest: calculateEMI(approvedAmount, monthlyROI, 6) * 6 - approvedAmount,
      recommended: true,
    },
    {
      tenure: 12,
      emiAmount: calculateEMI(approvedAmount, monthlyROI, 12),
      totalAmount: calculateEMI(approvedAmount, monthlyROI, 12) * 12,
      totalInterest: calculateEMI(approvedAmount, monthlyROI, 12) * 12 - approvedAmount,
      recommended: false,
    },
    {
      tenure: 24,
      emiAmount: calculateEMI(approvedAmount, monthlyROI, 24),
      totalAmount: calculateEMI(approvedAmount, monthlyROI, 24) * 24,
      totalInterest: calculateEMI(approvedAmount, monthlyROI, 24) * 24 - approvedAmount,
      recommended: false,
    },
    {
      tenure: 36,
      emiAmount: calculateEMI(approvedAmount, monthlyROI, 36),
      totalAmount: calculateEMI(approvedAmount, monthlyROI, 36) * 36,
      totalInterest: calculateEMI(approvedAmount, monthlyROI, 36) * 36 - approvedAmount,
      recommended: false,
    },
  ];

  const selectedPlan = emiPlans.find((p) => p.tenure === selectedTenure);
  const nextPaymentDate = new Date();
  nextPaymentDate.setMonth(nextPaymentDate.getMonth() + 1);
  const paymentDateStr = nextPaymentDate.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const handleEmiSelect = (tenure: number) => {
    setSelectedTenure(tenure);
  };

  const handleContinue = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      localStorage.setItem('selectedEMIScheme', JSON.stringify({ tenure: selectedTenure, plan: selectedPlan }));
      navigate('/bank-details');
    }, 1000);
  };

  const addComma = (amount: number) => {
    return amount.toLocaleString('en-IN');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="flex flex-col flex-grow overflow-y-auto pt-4 pb-24">
        <div className="max-w-2xl mx-auto w-full px-5">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900 mb-1">Select Your EMI Plan</h1>
            <p className="text-gray-600">Choose a monthly payment option that fits your budget</p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-sm mb-6">
            <div className="mb-2">
              <div className="text-gray-500 text-sm mb-1">Approved Loan Amount</div>
              <div className="text-4xl font-bold text-gray-900">₹{addComma(approvedAmount)}</div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600 mb-1">Processing Fee</p>
                <p className="font-semibold text-gray-900">₹{addComma(Math.round(processingFee))}</p>
              </div>
              <div>
                <p className="text-gray-600 mb-1">Interest Rate</p>
                <p className="font-semibold text-gray-900">1.5% per month</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between py-4">
            <div className="font-bold text-lg text-gray-900">Available EMI Plans</div>
          </div>

          <div className="space-y-3 mb-6">
            {emiPlans.map((plan) => (
              <div
                key={plan.tenure}
                onClick={() => handleEmiSelect(plan.tenure)}
                className={`w-full rounded-2xl p-4 cursor-pointer transition-all border-2 ${
                  selectedTenure === plan.tenure
                    ? 'border-green-600 bg-green-50'
                    : 'bg-white border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-grow">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-bold text-gray-900">
                        ₹{addComma(plan.emiAmount)} x {plan.tenure} months
                      </span>
                      {plan.recommended && (
                        <span className="text-xs px-2 py-1 text-green-700 rounded bg-green-100 font-medium">
                          Recommended
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600 text-xs">Total Interest</p>
                        <p className="font-semibold text-gray-900">₹{addComma(Math.round(plan.totalInterest))}</p>
                      </div>
                      <div>
                        <p className="text-gray-600 text-xs">Total Amount</p>
                        <p className="font-semibold text-gray-900">₹{addComma(Math.round(plan.totalAmount))}</p>
                      </div>
                      <div>
                        <p className="text-gray-600 text-xs">Cost per Month</p>
                        <p className="font-semibold text-gray-900">₹{addComma(plan.emiAmount)}</p>
                      </div>
                    </div>
                  </div>
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 mt-1 ${
                      selectedTenure === plan.tenure
                        ? 'border-green-600 bg-green-600'
                        : 'border-gray-300'
                    }`}
                  >
                    {selectedTenure === plan.tenure && (
                      <Check className="w-3 h-3 text-white" strokeWidth={3} />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-blue-50 rounded-2xl p-4 border border-blue-200 mb-4">
            <div className="flex gap-2">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-gray-900 mb-1">First payment details</p>
                <p className="text-gray-600">
                  Your first EMI of ₹{addComma(selectedPlan?.emiAmount || 0)} will be due on{' '}
                  <strong>{paymentDateStr}</strong>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-gray-900 shadow-lg">
        <div className="max-w-2xl mx-auto w-full">
          <div className="px-5 py-3">
            <label className="flex items-start gap-3 mb-3 cursor-pointer">
              <input
                type="checkbox"
                checked={checkBox}
                onChange={() => setCheckBox(!checkBox)}
                className="mt-1 w-4 h-4 accent-green-600"
              />
              <span className="text-xs text-gray-400 leading-relaxed">
                I agree to the terms and conditions and authorize the deduction of EMI from my registered bank account
              </span>
            </label>
          </div>
          <div className="px-5 pb-4">
            <button
              onClick={handleContinue}
              disabled={!checkBox || loading}
              className={`w-full h-12 rounded-lg font-semibold text-lg transition-all ${
                checkBox && !loading
                  ? 'bg-green-600 text-white hover:bg-green-700'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              {loading ? 'Processing...' : 'Confirm EMI Plan'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DummySchemePage;
