import { useState } from 'react';
import { FileText, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AgreementPage() {
  const navigate = useNavigate();
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleAccept = () => {
    if (!agreed) {
      alert('Please accept the terms and conditions');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      navigate('/otp-verification');
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-8 text-white">
          <div className="flex items-center gap-3 mb-4">
            <FileText className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Loan Agreement</h1>
          </div>
          <p className="text-indigo-100">Please review and accept the terms of your loan</p>
        </div>

        <div className="p-6">
          <div className="bg-gray-50 rounded-xl p-6 mb-6 max-h-96 overflow-y-auto border border-gray-200">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Loan Agreement Terms & Conditions</h2>

            <div className="space-y-4 text-sm text-gray-700">
              <section>
                <h3 className="font-semibold text-gray-900 mb-2">1. LOAN DETAILS</h3>
                <p>
                  This agreement is made between LoanApp Private Limited (the "Lender") and the borrower (the "Borrower") for a personal loan of ₹5,00,000 (Five Lakh Rupees Only).
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">2. INTEREST RATE</h3>
                <p>
                  The loan shall carry an interest rate of 1.5% per month (18% per annum) calculated on a reducing balance basis. The interest rate is fixed for the entire tenure of the loan.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">3. REPAYMENT TERMS</h3>
                <p>
                  The Borrower agrees to repay the loan in Equated Monthly Installments (EMIs) as per the schedule provided. The EMI includes both principal and interest components. Auto-debit mandate has been set up for seamless EMI deductions.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">4. PROCESSING FEE</h3>
                <p>
                  A processing fee of 2.5% of the loan amount will be deducted from the disbursal amount. This fee is non-refundable and covers the cost of loan processing and documentation.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">5. PREPAYMENT</h3>
                <p>
                  The Borrower may prepay the loan in full or in part at any time without any prepayment penalty. Partial prepayments will reduce the outstanding principal amount.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">6. DEFAULT AND CONSEQUENCES</h3>
                <p>
                  In case of default in payment of any EMI, the Lender reserves the right to charge penal interest at 2% per month on the overdue amount. Continued default may result in legal action and reporting to credit bureaus.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">7. USE OF LOAN</h3>
                <p>
                  The loan amount should be used only for the purpose stated in the application. The Lender reserves the right to recall the loan if found to be used for any illegal or unauthorized purpose.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">8. REPRESENTATIONS AND WARRANTIES</h3>
                <p>
                  The Borrower represents that all information provided in the application is true and accurate. Any misrepresentation may result in immediate cancellation of the loan and legal action.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">9. DISPUTE RESOLUTION</h3>
                <p>
                  Any disputes arising out of this agreement shall be subject to the exclusive jurisdiction of courts in Mumbai, India. The parties agree to attempt amicable resolution before pursuing legal remedies.
                </p>
              </section>

              <section>
                <h3 className="font-semibold text-gray-900 mb-2">10. GOVERNING LAW</h3>
                <p>
                  This agreement shall be governed by and construed in accordance with the laws of India. The Borrower agrees to comply with all applicable regulations and statutes.
                </p>
              </section>
            </div>
          </div>

          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200 mb-6">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="mt-1 w-5 h-5 accent-indigo-600"
              />
              <span className="text-sm text-gray-700">
                I have read and understood the terms and conditions mentioned above. I agree to abide by all the terms of this loan agreement and authorize LoanApp to disburse the loan amount to my registered bank account.
              </span>
            </label>
          </div>

          <button
            onClick={handleAccept}
            disabled={!agreed || loading}
            className="w-full bg-indigo-600 text-white py-4 rounded-lg font-bold text-lg hover:bg-indigo-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              'Processing...'
            ) : (
              <>
                <CheckCircle className="w-5 h-5" />
                Accept & Continue
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
