import { useEffect } from 'react';
import { Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function CreditCheckPage() {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/congratulations-mandate');
    }, 4000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
        <div className="mb-6">
          <Loader2 className="w-16 h-16 text-blue-600 animate-spin mx-auto" />
        </div>

        <h1 className="text-2xl font-bold text-gray-900 mb-2">
          Processing Your Application
        </h1>
        <p className="text-gray-600 mb-6">
          We're checking your credit limit and eligibility
        </p>

        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-3 text-left">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse" />
            <span className="text-sm text-gray-700">Verifying documents...</span>
          </div>
          <div className="flex items-center gap-3 text-left">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse delay-100" />
            <span className="text-sm text-gray-700">Checking credit score...</span>
          </div>
          <div className="flex items-center gap-3 text-left">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse delay-200" />
            <span className="text-sm text-gray-700">Calculating loan amount...</span>
          </div>
        </div>

        <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <p className="text-sm text-gray-600">
            This usually takes a few seconds. Please don't close this page.
          </p>
        </div>
      </div>
    </div>
  );
}
