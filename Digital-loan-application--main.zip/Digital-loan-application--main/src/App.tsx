import { Routes, Route, useNavigate } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import LoanApplicationForm from './pages/LoanApplicationForm';
import CongratulationsPage from './pages/CongratulationsPage';
import DummySchemePage from './pages/DummySchemePage';
import BankDetailsPage from './pages/BankDetailsPage';
import SelfiePage from './pages/SelfiePage';
import AadharKYCPage from './pages/AadharKYCPage';
import CreditCheckPage from './pages/CreditCheckPage';
import CongratulationsMandatePage from './pages/CongratulationsMandatePage';
import MandatePage from './pages/MandatePage';
import WithdrawalSummaryPage from './pages/WithdrawalSummaryPage';
import AgreementPage from './pages/AgreementPage';
import OTPVerificationPage from './pages/OTPVerificationPage';
import LoanDisbursedPage from './pages/LoanDisbursedPage';

function App() {
  const navigate = useNavigate();

  const handleApplicationSuccess = () => {
    navigate('/congratulations');
  };

  const handleCongratulationsComplete = () => {
    navigate('/emi-scheme');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route
          path="/application"
          element={<LoanApplicationForm onSuccess={handleApplicationSuccess} />}
        />
        <Route
          path="/congratulations"
          element={<CongratulationsPage onContinue={handleCongratulationsComplete} />}
        />
        <Route path="/emi-scheme" element={<DummySchemePage approvedAmount={500000} />} />
        <Route path="/bank-details" element={<BankDetailsPage />} />
        <Route path="/selfie-verification" element={<SelfiePage />} />
        <Route path="/aadhar-kyc" element={<AadharKYCPage />} />
        <Route path="/credit-check" element={<CreditCheckPage />} />
        <Route path="/congratulations-mandate" element={<CongratulationsMandatePage />} />
        <Route path="/mandate" element={<MandatePage />} />
        <Route path="/withdrawal-summary" element={<WithdrawalSummaryPage />} />
        <Route path="/agreement" element={<AgreementPage />} />
        <Route path="/otp-verification" element={<OTPVerificationPage />} />
        <Route path="/loan-disbursed" element={<LoanDisbursedPage />} />
      </Routes>
    </div>
  );
}

export default App;
